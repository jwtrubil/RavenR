#' Custom Output Data from Raven
#'
#' A dataset formatted to the xts package, read in by the custom.read function.
#' The dataset contains average SNOW for each HRU in the Nith river model, available
#' for download in the Raven Tutorials (linked below).
#'
#' The Nith River model can be downloaded from the Raven Tutorials (tutorial #2)
#' \url{http://www.civil.uwaterloo.ca/jrcraig/Raven/Downloads.html}
#'
#' @seealso \code{\link{custom.read}} for reading in custom output files
#' @seealso \code{\link{customoutput.plot}} for plotting custom output
#'
#'
#' @format A data frame with 730 rows, containg data for 32 HRUs from 2002-10-01 to 2004-09-29
#'
"custom.data"
